"""
Image filters — variacao do image_convolution focada em operacoes COMPOSTAS,
que exigem varias passadas (ping-pong de framebuffers na GPU).

O shader filter.glsl implementa uma operacao por passada (COPY, GRAY, CONV3,
BLUR1D, GRADMAG, NMS, THRESH, HYST, FINALIZE, COMBINE). Aqui em Python cada
filtro e montado encadeando essas passadas entre framebuffers de rascunho.

Filtros:
  - original
  - grayscale
  - gaussian blur     : blur separavel  (H, depois V)               -> 2 passadas
  - box blur 3x3      : convolucao unica
  - sharpen           : convolucao unica
  - unsharp masking   : blur + combine  (orig + amount*(orig-blur))  -> 3 passadas
  - sobel             : magnitude do gradiente
  - prewitt           : idem, com pesos de Prewitt
  - emboss            : convolucao unica
  - DoG               : difference of gaussians (2 blurs + combine)
  - canny             : gray -> blur -> gradiente -> supressao nao-maxima ->
                        duplo limiar -> histerese                    -> ~12 passadas
"""
from gui import GuiBlock

SRC = 320  # resolucao de trabalho

image_files = {
    "cameraman": "cameraman.bmp",
    "lenna": "lenna.bmp",
    "baboon": "baboon.bmp",
}

# Constantes de passada (espelham filter.glsl)
COPY, GRAY, CONV3, BLUR1D, GRADMAG, MAGVIEW, NMS, THRESH, HYST, FINALIZE, COMBINE = range(11)

filters = ["grayscale", "gaussian blur", "box blur", "sharpen",
           "unsharp masking", "sobel", "prewitt", "emboss", "DoG", "canny"]


def preload():
    global vert_src, filter_src, images
    vert_src = loadStrings("vert.glsl")
    filter_src = loadStrings("filter.glsl")
    images = {name: loadImage(f) for name, f in image_files.items()}


def _join(lines):
    return "\n".join(str(s) for s in lines)


def setup():
    createCanvas(windowWidth, windowHeight, WEBGL)
    pixelDensity(1)

    global fshader
    fshader = createShader(_join(vert_src), _join(filter_src))

    for img in images.values():
        img.resize(SRC, SRC)

    # Pool de framebuffers de rascunho (ping-pong).
    global fbs
    fbs = [create_framebuffer(js_object(
        {"width": SRC, "height": SRC, "density": 1})) for _ in range(4)]

    # GuiBlock MESTRE: imagem + algoritmo.
    global master
    master = GuiBlock("Filtro")
    master.addSelect("image", image_files.keys(), "cameraman")
    master.addSelect("algorithm", filters, "sobel")
    master.change(select_filter)
    master.position(10, 10)

    # Um GuiBlock de parametros por algoritmo, todos na mesma posicao.
    global param_blocks
    param_blocks = {}

    def add_block(name, builder=None):
        title = name if builder else name + " (sem parametros)"
        g = GuiBlock(title)
        if builder:
            builder(g)
            g.position(10, 120)
        else: 
            g.position(0,-200)
        param_blocks[name] = g

    add_block("grayscale")
    add_block("gaussian blur", lambda g: g.addNumber("raio", 1, 12, 3, 1))
    add_block("box blur")
    add_block("sharpen")
    add_block("unsharp masking", lambda g: (
        g.addNumber("raio", 1, 12, 3, 1),
        g.addNumber("amount", 0.0, 4.0, 1.5, 0.1)))
    add_block("sobel", lambda g: g.addNumber("ganho", 0.5, 5.0, 1.5, 0.1))
    add_block("prewitt", lambda g: g.addNumber("ganho", 0.5, 5.0, 1.5, 0.1))
    add_block("emboss")
    add_block("DoG", lambda g: (
        g.addNumber("raio", 1, 12, 3, 1),
        g.addNumber("ganho", 0.5, 5.0, 1.5, 0.1)))
    add_block("canny", lambda g: (
        g.addNumber("raio", 1, 12, 2, 1),
        g.addNumber("ganho", 0.5, 5.0, 1.5, 0.1),
        g.addNumber("limiar_alto", 0.0, 1.0, 0.30, 0.01),
        g.addNumber("limiar_baixo", 0.0, 1.0, 0.10, 0.01)))

    select_filter()

    global label
    label = create_div("")
    label.style("position", "absolute")
    label.style("color", "white")
    label.style("font", GuiBlock.font)
    label.style("text-align", "center")
    label.style("transform", "translateX(-50%)")
    label.style("text-shadow", "0 1px 3px black")
    label.style("pointer-events", "none")


def select_filter():
    """Mapeia/desmapeia os GuiBlocks de parametros via display."""
    active = master.algorithm
    for name, blk in param_blocks.items():
        blk.div.style("display", "block" if name == active else "none")


def run(dst, p, tex0, tex1=None, kernel=None, div=1.0, bias=0.0, gray=0,
        dir=(1, 0), sigma=1.0, radius=1, op=0, scale=1.0, a=1.0, b=0.0, c=0.0,
        hi=0.3, lo=0.1):
    """Executa uma passada do shader, escrevendo em dst."""
    dst.begin()
    clear()
    shader(fshader)
    fshader.setUniform("u_pass", p)
    fshader.setUniform("u_tex0", tex0)
    fshader.setUniform("u_tex1", tex1 if tex1 is not None else tex0)
    fshader.setUniform("u_kernel", js_array(kernel if kernel else [0.0] * 9))
    fshader.setUniform("u_div", float(div))
    fshader.setUniform("u_bias", float(bias))
    fshader.setUniform("u_gray", int(gray))
    fshader.setUniform("u_dir", js_array([float(dir[0]), float(dir[1])]))
    fshader.setUniform("u_sigma", float(sigma))
    fshader.setUniform("u_radius", int(radius))
    fshader.setUniform("u_op", int(op))
    fshader.setUniform("u_scale", float(scale))
    fshader.setUniform("u_a", float(a))
    fshader.setUniform("u_b", float(b))
    fshader.setUniform("u_c", float(c))
    fshader.setUniform("u_hi", float(hi))
    fshader.setUniform("u_lo", float(lo))
    no_stroke()
    plane(dst.width, dst.height)
    dst.end()
    reset_shader()


def gaussian(src, dst, tmp, radius):
    """Blur gaussiano separavel: horizontal (-> tmp) e vertical (-> dst)."""
    s = max(radius / 2.0, 0.5)
    run(tmp, BLUR1D, src, dir=(1, 0), radius=radius, sigma=s)
    run(dst, BLUR1D, tmp, dir=(0, 1), radius=radius, sigma=s)


def apply_filter(name, src):
    f0, f1, f2, f3 = fbs
    pb = param_blocks[name]

    if name == "grayscale":
        run(f0, GRAY, src); return f0
    if name == "gaussian blur":
        gaussian(src, f1, f0, int(pb.raio)); return f1
    if name == "box blur":
        run(f0, CONV3, src, kernel=[1, 1, 1, 1, 1, 1, 1, 1, 1], div=9.0); return f0
    if name == "sharpen":
        run(f0, CONV3, src, kernel=[0, -1, 0, -1, 5, -1, 0, -1, 0], div=1.0); return f0
    if name == "unsharp masking":
        gaussian(src, f1, f0, int(pb.raio))            # f1 = borrada
        amt = pb.amount
        run(f2, COMBINE, src, f1, a=1.0 + amt, b=-amt) # orig + amt*(orig-blur)
        return f2
    if name == "sobel":
        run(f0, GRADMAG, src, op=0, scale=pb.ganho)
        run(f1, MAGVIEW, f0); return f1
    if name == "prewitt":
        run(f0, GRADMAG, src, op=1, scale=pb.ganho)
        run(f1, MAGVIEW, f0); return f1
    if name == "emboss":
        run(f0, CONV3, src, kernel=[-2, -1, 0, -1, 1, 1, 0, 1, 2], div=1.0,
            bias=0.0, gray=1)
        return f0
    if name == "DoG":
        r = int(pb.raio)
        gaussian(src, f1, f0, r)       # f1 = borrada pequena
        gaussian(src, f3, f2, r * 2)   # f3 = borrada grande
        run(f0, COMBINE, f1, f3, a=pb.ganho, b=-pb.ganho, c=0.5)
        return f0
    if name == "canny":
        run(f0, GRAY, src)
        gaussian(f0, f0, f1, int(pb.raio))         # suaviza (f0 -> f1 -> f0)
        run(f1, GRADMAG, f0, op=0, scale=pb.ganho) # gradiente (empacotado)
        run(f0, NMS, f1)                           # supressao nao-maxima
        run(f1, THRESH, f0, hi=pb.limiar_alto, lo=pb.limiar_baixo)
        cur, other = f1, f0
        for _ in range(6):                         # histerese iterativa
            run(other, HYST, cur)
            cur, other = other, cur
        run(other, FINALIZE, cur)
        return other
    run(f0, COPY, src)
    return f0


def draw():
    background(30)

    src = images[master.image]
    result = apply_filter(master.algorithm, src)

    a = width * 0.42
    b = height * 0.72
    size = a if a < b else b
    gap = 24
    cdx = size / 2 + gap / 2

    image(src, -cdx - size / 2, -size / 2, size, size)
    image(result, cdx - size / 2, -size / 2, size, size)

    label.html(f"{master.image}  →  {master.algorithm}")
    label.position(int(width / 2 + cdx), int(height / 2 + size / 2 + 10))
    label.style("width", f"{int(size)}px")


def window_resized():
    resizeCanvas(windowWidth, windowHeight)
